﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace DemoConnect.testDB
{
    public partial class mydatabaseContext : DbContext
    {
        public mydatabaseContext()
        {
        }

        public mydatabaseContext(DbContextOptions<mydatabaseContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Dept> Depts { get; set; }
        public virtual DbSet<Emp> Emps { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=HSHLT-1694\\SQLEXPRESS01;Database=mydatabase;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<Dept>(entity =>
            {
                entity.HasKey(e => e.Deptno)
                    .HasName("pk_dept");

                entity.ToTable("dept");

                entity.Property(e => e.Deptno)
                    .HasColumnType("numeric(2, 0)")
                    .HasColumnName("deptno");

                entity.Property(e => e.Dname)
                    .HasMaxLength(14)
                    .IsUnicode(false)
                    .HasColumnName("dname");

                entity.Property(e => e.Loc)
                    .HasMaxLength(13)
                    .IsUnicode(false)
                    .HasColumnName("loc");
            });

            modelBuilder.Entity<Emp>(entity =>
            {
                entity.HasKey(e => e.Empno)
                    .HasName("pk_emp");

                entity.ToTable("emp");

                entity.Property(e => e.Empno)
                    .HasColumnType("numeric(4, 0)")
                    .HasColumnName("empno");

                entity.Property(e => e.Comm)
                    .HasColumnType("numeric(7, 2)")
                    .HasColumnName("comm");

                entity.Property(e => e.Deptno)
                    .HasColumnType("numeric(2, 0)")
                    .HasColumnName("deptno");

                entity.Property(e => e.Ename)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("ename");

                entity.Property(e => e.Hiredate)
                    .HasColumnType("date")
                    .HasColumnName("hiredate");

                entity.Property(e => e.Job)
                    .HasMaxLength(9)
                    .IsUnicode(false)
                    .HasColumnName("job");

                entity.Property(e => e.Mgr)
                    .HasColumnType("numeric(4, 0)")
                    .HasColumnName("mgr");

                entity.Property(e => e.Sal)
                    .HasColumnType("numeric(7, 2)")
                    .HasColumnName("sal");

                entity.HasOne(d => d.DeptnoNavigation)
                    .WithMany(p => p.Emps)
                    .HasForeignKey(d => d.Deptno)
                    .HasConstraintName("fk_deptno");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
